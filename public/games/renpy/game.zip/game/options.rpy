
define config.name = _("CyberSec Mastery")
define gui.show_name = True
define config.version = "1.0"
define gui.about = _("")
define build.name = "CyberSecGame"

# Set window icon and other properties
define config.has_sound = True
define config.has_music = True
define config.has_voice = True

# Standard Ren'Py setup
define config.main_menu_music = None
define config.enter_transition = dissolve
define config.exit_transition = dissolve
define config.after_load_transition = None
define config.end_game_transition = None
define config.window_icon = None
