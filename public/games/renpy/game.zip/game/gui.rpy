
## GUI configuration - CyberSec game theme
## Dark/green hacker aesthetic

# Colors
define gui.accent_color = '#00ff00'
define gui.idle_color = '#aaaaaa'
define gui.hover_color = '#ffffff'
define gui.selected_color = '#ffffff'
define gui.insensitive_color = '#555555'
define gui.muted_color = '#003300'
define gui.hover_muted_color = '#004400'
define gui.selected_muted_color = '#003300'
define gui.selected_hover_muted_color = '#004400'

# Text sizes
define gui.text_size = 30
define gui.name_text_size = 45
define gui.interface_text_size = 30

## Fonts
define gui.text_font = "DejaVuSans.ttf"
define gui.name_text_font = "DejaVuSans.ttf"
define gui.interface_text_font = "DejaVuSans.ttf"

## Dialogue
define gui.textbox_height = 278
define gui.name_xpos = 360
define gui.name_ypos = 0
define gui.dialogue_xpos = 398
define gui.dialogue_ypos = 75
define gui.dialogue_width = 1125

## Window
style default:
    font "DejaVuSans.ttf"
    size 30
    color "#ffffff"

style window:
    xalign 0.5
    xfill True
    yalign 1.0
    ysize 278
    background Frame(Solid("#000000cc"), 4, 4)
    padding (40, 20)

style namebox:
    xpos 360
    xanchor 0.0
    ypos 0
    yanchor 0.0
    background Frame(Solid("#00aa0099"), 6, 6)
    padding (15, 5)

style say_label:
    color "#00ff00"
    font "DejaVuSans.ttf"
    size 45
    xalign 0.0

style say_dialogue:
    color "#ffffff"
    font "DejaVuSans.ttf"
    size 30
    xpos 398
    ypos 75
    xsize 1125
    
## Choice menus
style choice_vbox:
    xalign 0.5
    ypos 400
    yanchor 0.5
    spacing 10

style choice_button:
    is default
    xsize 700
    background Solid("#1a1a1acc")
    hover_background Solid("#00aa00cc")
    padding (20, 12)
    xalign 0.5

style choice_button_text:
    is default
    xalign 0.5
    color "#aaffaa"
    hover_color "#000000"
    size 28
