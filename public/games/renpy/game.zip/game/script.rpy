# ═══════════════════════════════════════════════════════════════
#  CYBERSEC MASTERY — A Cybersecurity Awareness Visual Novel
#  5 Levels • Branching Choices • Interactive Screens
# ═══════════════════════════════════════════════════════════════

# ─────────────────────────────────────────────
# IMAGE DEFINITIONS
# ─────────────────────────────────────────────

# ── Characters (New Processed Assets) ──
image arjun = im.Scale("images/arjun.png", 370, 650)
image riya = im.Scale("images/riya.png", 370, 650)
image prof_meera = im.Scale("images/prof_meera.png", 370, 650)
image rahul = im.Scale("images/rahul.png", 370, 650)
image ananya = im.Scale("images/ananya.png", 370, 650)
image vikram = im.Scale("images/vikram.png", 370, 650)
image naveen = im.Scale("images/naveen.png", 370, 650)
image sanjay = im.Scale("images/sanjay.png", 370, 650)
image kavita = im.Scale("images/kavita.png", 370, 650)
image zoe = im.Scale("images/zoe.png", 370, 650)
image amit = im.Scale("images/amit.png", 370, 650)
image maya = im.Scale("images/maya.png", 370, 650)
image rajesh = im.Scale("images/rajesh.png", 370, 650)
image hacker = im.Scale("images/hacker.png", 370, 650)
image family_happy = im.Scale("images/family_happy.png", 700, 500)
image office_team = im.Scale("images/office_team.png", 700, 500)

# Backgrounds
image bg_office = im.Scale("images/bg_office.jpg", 1920, 1080)
image bg_school = im.Scale("images/bg_school.jpg", 1920, 1080)
image bg_campus = im.Scale("images/bg_campus.jpg", 1920, 1080)
image bg_bank = im.Scale("images/bg_bank.jpg", 1920, 1080)
image bg_home = im.Scale("images/bg_office.jpg", 1920, 1080)

# ─────────────────────────────────────────────
# CHARACTER DEFINITIONS
# ─────────────────────────────────────────────

define narrator_voice = Character(None, what_color="#cccccc")
define arj = Character("Arjun", color="#00ccff", what_color="#ffffff")
define meera = Character("Prof. Meera", color="#ff99cc", what_color="#ffffff")
define rah = Character("Rahul", color="#66ff66", what_color="#ffffff")
define ana = Character("Ananya", color="#ffcc66", what_color="#ffffff")
define riy = Character("Riya", color="#ff6699", what_color="#ffffff")
define caller = Character("Bank Officer", color="#ffaa00", what_color="#ffffff")
define vik = Character("Vikram", color="#66ccff", what_color="#ffffff")
define nav = Character("Naveen", color="#00ff99", what_color="#ffffff")
define san = Character("Sanjay", color="#66ffcc", what_color="#ffffff")
define kav = Character("Kavita", color="#ff99ff", what_color="#ffffff")
define zoe = Character("Zoe", color="#ccff99", what_color="#ffffff")
define ami = Character("Dr. Amit", color="#99ccff", what_color="#ffffff")
define may = Character("Maya", color="#ffccff", what_color="#ffffff")
define printer = Character(" rajesh", color="#ffaa00", what_color="#ffffff")
define hacker = Character("??? HACKER ???", color="#ff3333", what_color="#ff9999")
define sys = Character("SYSTEM", color="#aaaaaa", what_color="#cccccc")

# ─────────────────────────────────────────────
# GAME STATE VARIABLES
# ─────────────────────────────────────────────

default secure_bar = 80
default level_1_done = False
default level_2_done = False
default level_3_done = False
default level_4_done = False
default level_5_done = False
default level_6_done = False
default level_7_done = False
default level_8_done = False
default level_9_done = False
default level_10_done = False
default gave_otp = False
default installed_toolbar = False
default chose_evil_wifi = False

# ─────────────────────────────────────────────
# SECURE BAR HUD
# ─────────────────────────────────────────────

screen secure_bar_display():
    frame:
        xalign 0.97
        yalign 0.04
        padding (15, 12)
        background Frame(Solid("#00000099"), 6, 6)
        vbox:
            spacing 6
            text "🛡 System Integrity" size 18 color "#00ff99"
            bar value secure_bar range 100 xsize 220 ysize 16 left_bar Solid("#00ff44") right_bar Solid("#333333")
            text "[secure_bar]%%" size 16 color "#aaffaa" xalign 1.0

# ═══════════════════════════════════════════════════════════════
#  CUSTOM INTERACTIVE SCREENS
# ═══════════════════════════════════════════════════════════════

# ── Screen 0: Email Notification on Phone (Level 1) ──
screen email_phone_screen():
    modal True
    # Dim background overlay
    add Solid("#00000099")

    # ── Phone Frame ──
    frame:
        xalign 0.5
        yalign 0.5
        xsize 340
        ysize 620
        padding (0, 0)
        background Frame(Solid("#111111ff"), 20, 20)

        # Phone body
        vbox:
            xfill True

            # ── Status bar ──
            frame:
                xfill True
                ysize 28
                padding (12, 4)
                background Solid("#1a1a1a")
                hbox:
                    text "9:41" size 12 color "#ffffff"
                    xfill True
                    text "📶  🔋" size 12 color "#ffffff" xalign 1.0

            # ── Notch ──
            frame:
                xalign 0.5
                xsize 120
                ysize 6
                background Frame(Solid("#000000"), 8, 8)

            null height 8

            # ── App Header: Mail ──
            frame:
                xfill True
                ysize 40
                padding (16, 8)
                background Solid("#1c1c1e")
                hbox:
                    text "✉  Inbox" size 18 color "#ffffff" yalign 0.5
                    xfill True
                    text "1 new" size 13 color "#ff3b30" yalign 0.5 xalign 1.0

            # ── Unread badge ──
            frame:
                xfill True
                padding (12, 6)
                background Solid("#222222")
                hbox:
                    spacing 6
                    text "●" size 10 color "#007aff" yalign 0.0
                    text "Unread (1)" size 12 color "#8e8e93"

            null height 4

            # ── Email Card ──
            frame:
                xfill True
                xsize 320
                padding (14, 12)
                xalign 0.5
                background Frame(Solid("#1c1c1eff"), 10, 10)
                vbox:
                    spacing 6
                    # Sender + time
                    hbox:
                        text "IT_SECURITY" size 13 color "#ffffff" bold True
                        xfill True
                        text "9:32 AM" size 11 color "#8e8e93" xalign 1.0
                    # Sender email
                    text "@cybersafe-helpdesk.net" size 10 color "#ff9500"
                    null height 2
                    # Subject
                    text "URGENT — Verify Your Account" size 14 color "#ffffff" bold True
                    text "or Face Suspension" size 14 color "#ffffff" bold True
                    null height 4
                    # Preview
                    text "Dear Employee, your account will be locked in 24 hours unless you verify..." size 11 color "#8e8e93"
                    null height 4
                    # Link preview
                    frame:
                        xfill True
                        padding (8, 6)
                        background Frame(Solid("#2c2c2eff"), 6, 6)
                        hbox:
                            text "🔗" size 12
                            text " cybersafe-helpdesk.net/verify" size 10 color "#007aff"

            null height 10

            # ── Action Buttons (Phone-style) ──
            vbox:
                spacing 8
                xalign 0.5

                textbutton "🔍  Open & Inspect Carefully" action [Hide("email_phone_screen"), Return("inspect")]:
                    xsize 300
                    xalign 0.5
                    padding (12, 10)
                    background Frame(Solid("#007aff"), 8, 8)
                    hover_background Frame(Solid("#0a84ff"), 8, 8)
                    text_color "#ffffff"
                    text_size 13

                textbutton "🗑  Delete Without Opening" action [Hide("email_phone_screen"), Return("delete")]:
                    xsize 300
                    xalign 0.5
                    padding (12, 10)
                    background Frame(Solid("#333333"), 8, 8)
                    hover_background Frame(Solid("#555555"), 8, 8)
                    text_color "#ffffff"
                    text_size 13

                textbutton "⚡  Tap Link Now — It's Urgent!" action [Hide("email_phone_screen"), Return("click")]:
                    xsize 300
                    xalign 0.5
                    padding (12, 10)
                    background Frame(Solid("#ff3b30"), 8, 8)
                    hover_background Frame(Solid("#ff6961"), 8, 8)
                    text_color "#ffffff"
                    text_size 13

            null height 10

            # ── Home indicator ──
            frame:
                xalign 0.5
                xsize 100
                ysize 4
                background Frame(Solid("#666666"), 4, 4)

# ── Screen 1: Brute Force Password Demo (Level 2) ──
screen brute_force_demo():
    modal True
    frame:
        xalign 0.5
        yalign 0.5
        padding (40, 30)
        background Frame(Solid("#0a0a0aee"), 8, 8)
        xsize 700
        vbox:
            spacing 12
            text "⚡ BRUTE FORCE ATTACK SIMULATION ⚡" size 24 color "#ff3333" xalign 0.5
            text "━━━━━━━━━━━━━━━━━━━━━━━━━━━━" size 14 color "#333333" xalign 0.5
            null height 10
            text "Attempting password: {color=#00ff00}aaa123{/color}" size 18 color "#888888"
            text "Attempting password: {color=#00ff00}admin1{/color}" size 18 color "#888888"
            text "Attempting password: {color=#00ff00}pass123{/color}" size 18 color "#888888"
            text "Attempting password: {color=#00ff00}qwerty{/color}" size 18 color "#888888"
            text "Attempting password: {color=#00ff00}123456{/color}" size 18 color "#888888"
            text "Attempting password: {color=#ff3333}password{/color}" size 18 color "#ff3333"
            null height 5
            text "✓ PASSWORD CRACKED in 0.3 seconds!" size 20 color "#ff3333" xalign 0.5
            text "\"password\" was found in the top 10 most common passwords." size 16 color "#ffaa00" xalign 0.5
            null height 15
            textbutton "[[ CLOSE SIMULATION ]]" action [Hide("brute_force_demo"), Return()] xalign 0.5:
                text_color "#00ff99"
                text_hover_color "#ffffff"
                text_size 20

# ── Screen 2: Incoming Call on Phone (Level 3) ──
screen phone_popup():
    modal True
    add Solid("#00000099")

    # ── Phone Frame ──
    frame:
        xalign 0.5
        yalign 0.5
        xsize 340
        ysize 580
        padding (0, 0)
        background Frame(Solid("#111111ff"), 20, 20)

        vbox:
            xfill True

            # ── Status bar ──
            frame:
                xfill True
                ysize 28
                padding (12, 4)
                background Solid("#1a1a1a")
                hbox:
                    text "9:41" size 12 color "#ffffff"
                    xfill True
                    text "📶  🔋" size 12 color "#ffffff" xalign 1.0

            # ── Notch ──
            frame:
                xalign 0.5
                xsize 120
                ysize 6
                background Frame(Solid("#000000"), 8, 8)

            null height 30

            # ── Caller Info ──
            vbox:
                xalign 0.5
                spacing 8

                # Avatar circle
                frame:
                    xalign 0.5
                    xsize 80
                    ysize 80
                    padding (0, 0)
                    background Frame(Solid("#333333"), 40, 40)
                    text "🏦" size 36 xalign 0.5 yalign 0.5

                null height 10

                text "National Secure Bank" size 20 color "#ffffff" xalign 0.5
                text "+91 98XX-XXXX42" size 14 color "#8e8e93" xalign 0.5

                null height 6
                text "incoming call..." size 13 color "#8e8e93" xalign 0.5

            null height 40

            # ── Quick Actions Row ──
            hbox:
                xalign 0.5
                spacing 35
                vbox:
                    xalign 0.5
                    spacing 4
                    frame:
                        xalign 0.5
                        xsize 44
                        ysize 44
                        background Frame(Solid("#333333"), 22, 22)
                        text "🔇" size 18 xalign 0.5 yalign 0.5
                    text "Mute" size 10 color "#8e8e93" xalign 0.5
                vbox:
                    xalign 0.5
                    spacing 4
                    frame:
                        xalign 0.5
                        xsize 44
                        ysize 44
                        background Frame(Solid("#333333"), 22, 22)
                        text "💬" size 18 xalign 0.5 yalign 0.5
                    text "Message" size 10 color "#8e8e93" xalign 0.5
                vbox:
                    xalign 0.5
                    spacing 4
                    frame:
                        xalign 0.5
                        xsize 44
                        ysize 44
                        background Frame(Solid("#333333"), 22, 22)
                        text "⏰" size 18 xalign 0.5 yalign 0.5
                    text "Remind" size 10 color "#8e8e93" xalign 0.5

            null height 40

            # ── Accept / Decline Circular Buttons ──
            hbox:
                xalign 0.5
                spacing 80

                # Decline
                vbox:
                    xalign 0.5
                    spacing 6
                    textbutton "✕" action [Hide("phone_popup"), Return("decline")]:
                        xsize 64
                        ysize 64
                        background Frame(Solid("#ff3b30"), 32, 32)
                        hover_background Frame(Solid("#ff6961"), 32, 32)
                        text_color "#ffffff"
                        text_size 28
                        xalign 0.5
                        text_xalign 0.5
                        text_yalign 0.5
                    text "Decline" size 12 color "#ff3b30" xalign 0.5

                # Accept
                vbox:
                    xalign 0.5
                    spacing 6
                    textbutton "✓" action [Hide("phone_popup"), Return("accept")]:
                        xsize 64
                        ysize 64
                        background Frame(Solid("#34c759"), 32, 32)
                        hover_background Frame(Solid("#5cdb7e"), 32, 32)
                        text_color "#ffffff"
                        text_size 28
                        xalign 0.5
                        text_xalign 0.5
                        text_yalign 0.5
                    text "Accept" size 12 color "#34c759" xalign 0.5

            null height 15

            # Home indicator
            frame:
                xalign 0.5
                xsize 100
                ysize 4
                background Frame(Solid("#666666"), 4, 4)

# ── Screen 3: Fake Installer UI (Level 4) ──
screen installer_ui():
    modal True
    default toolbar_checked = True
    frame:
        xalign 0.5
        yalign 0.5
        padding (35, 30)
        background Frame(Solid("#f0f0f0ff"), 8, 8)
        xsize 600
        vbox:
            spacing 12
            text "SuperCodeEditor v3.1 — Setup Wizard" size 22 color "#333333" xalign 0.5
            text "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" size 12 color "#cccccc" xalign 0.5
            null height 10
            text "Installation Options:" size 18 color "#555555"
            null height 5

            hbox:
                spacing 10
                text "☑" size 20 color "#333333"
                text "Install SuperCodeEditor (required)" size 16 color "#555555"

            hbox:
                spacing 10
                text "☑" size 20 color "#333333"
                text "Create Desktop Shortcut" size 16 color "#555555"

            hbox:
                spacing 10
                if toolbar_checked:
                    textbutton "☑" action SetScreenVariable("toolbar_checked", False) text_size 20 text_color "#333333"
                else:
                    textbutton "☐" action SetScreenVariable("toolbar_checked", True) text_size 20 text_color "#333333"
                text "Install BonusSearchToolbar™ (Recommended)" size 15 color "#999999"

            null height 5
            text "{size=11}{color=#bbbbbb}BonusSearchToolbar™ may modify browser settings, set default search engine, and collect usage data.{/color}{/size}" xalign 0.5

            null height 15
            hbox:
                spacing 20
                xalign 0.5
                textbutton "  INSTALL  " action [Hide("installer_ui"), Return(toolbar_checked)]:
                    background Solid("#2266cccc")
                    hover_background Solid("#3388ee")
                    padding (30, 10)
                    text_color "#ffffff"
                    text_size 18
                textbutton "  CANCEL  " action [Hide("installer_ui"), Return("cancel")]:
                    background Solid("#cccccccc")
                    hover_background Solid("#aaaaaa")
                    padding (30, 10)
                    text_color "#333333"
                    text_size 18

# ── Screen 4: Wi-Fi Selection on Phone (Level 5) ──
screen wifi_selection():
    modal True
    add Solid("#00000099")

    # ── Phone Frame ──
    frame:
        xalign 0.5
        yalign 0.5
        xsize 340
        ysize 560
        padding (0, 0)
        background Frame(Solid("#111111ff"), 20, 20)

        vbox:
            xfill True

            # ── Status bar ──
            frame:
                xfill True
                ysize 28
                padding (12, 4)
                background Solid("#1a1a1a")
                hbox:
                    text "9:41" size 12 color "#ffffff"
                    xfill True
                    text "📶  🔋" size 12 color "#ffffff" xalign 1.0

            # ── Notch ──
            frame:
                xalign 0.5
                xsize 120
                ysize 6
                background Frame(Solid("#000000"), 8, 8)

            null height 4

            # ── Settings Header ──
            frame:
                xfill True
                ysize 44
                padding (12, 8)
                background Solid("#1c1c1e")
                hbox:
                    text "< Settings" size 14 color "#007aff" yalign 0.5
                    xfill True
                    text "Wi-Fi" size 18 color "#ffffff" xalign 0.5 yalign 0.5

            null height 4

            # ── Wi-Fi Toggle ──
            frame:
                xfill True
                padding (14, 10)
                background Solid("#1c1c1e")
                hbox:
                    text "Wi-Fi" size 15 color "#ffffff" yalign 0.5
                    xfill True
                    frame:
                        xalign 1.0
                        xsize 44
                        ysize 24
                        background Frame(Solid("#34c759"), 12, 12)
                        frame:
                            xalign 1.0
                            xsize 20
                            ysize 20
                            yalign 0.5
                            background Frame(Solid("#ffffff"), 10, 10)

            null height 8

            # ── Networks Section ──
            frame:
                xfill True
                padding (14, 6)
                background Solid("#1c1c1e")
                text "AVAILABLE NETWORKS" size 11 color "#8e8e93"

            null height 2

            # Network: Evil Twin (Open)
            button:
                action [Hide("wifi_selection"), Return("evil_twin")]
                xfill True
                padding (0, 0)
                background Solid("#1c1c1e")
                hover_background Solid("#2c2c2e")
                frame:
                    xfill True
                    padding (14, 12)
                    background None
                    hbox:
                        text "📶" size 16 yalign 0.5
                        null width 8
                        vbox:
                            text "BeanAndBrew_FreeWiFi" size 14 color "#ffffff"
                            text "Open Network" size 10 color "#ff9500"
                        xfill True
                        text "🔓" size 16 color "#ff9500" xalign 1.0 yalign 0.5

            # Separator
            frame:
                xfill True
                ysize 1
                xpadding 14
                background Solid("#333333")

            # Network: Legit (WPA2)
            button:
                action [Hide("wifi_selection"), Return("legit")]
                xfill True
                padding (0, 0)
                background Solid("#1c1c1e")
                hover_background Solid("#2c2c2e")
                frame:
                    xfill True
                    padding (14, 12)
                    background None
                    hbox:
                        text "📶" size 16 yalign 0.5
                        null width 8
                        vbox:
                            text "BeanAndBrew_Guest" size 14 color "#ffffff"
                            text "WPA2 Secured" size 10 color "#34c759"
                        xfill True
                        text "🔒" size 16 color "#34c759" xalign 1.0 yalign 0.5

            # Separator
            frame:
                xfill True
                ysize 1
                xpadding 14
                background Solid("#333333")

            # Network: Other (WPA3)
            button:
                action [Hide("wifi_selection"), Return("other")]
                xfill True
                padding (0, 0)
                background Solid("#1c1c1e")
                hover_background Solid("#2c2c2e")
                frame:
                    xfill True
                    padding (14, 12)
                    background None
                    hbox:
                        text "📶" size 14 yalign 0.5
                        null width 8
                        vbox:
                            text "HomeNetwork_5G" size 14 color "#8e8e93"
                            text "WPA3 Secured" size 10 color "#34c759"
                        xfill True
                        text "🔒" size 16 color "#34c759" xalign 1.0 yalign 0.5

            null height 8

            # ── Tip ──
            frame:
                xfill True
                padding (14, 8)
                background Solid("#111111")
                text "⚠ Open networks don't encrypt your data" size 10 color "#ff9500" xalign 0.5

            null height 10

            # Home indicator
            frame:
                xalign 0.5
                xsize 100
                ysize 4
                background Frame(Solid("#666666"), 4, 4)


# ═══════════════════════════════════════════════════════════════
#  LEVEL MAP — CANDY CRUSH STYLE PATH SELECTION
# ═══════════════════════════════════════════════════════════════

init python:
    import math

    # Level node positions on 1920x1080 canvas (winding S-curve)
    level_nodes = [
        {"x": 350,  "y": 900, "title": "Phishing",    "icon": u"\u2709\ufe0f",  "full": "The Suspicious Email"},
        {"x": 1200, "y": 900, "title": "Passwords",    "icon": u"\U0001f511",    "full": "Password Security"},
        {"x": 1200, "y": 720, "title": "Social Eng.",   "icon": u"\U0001f4de",   "full": "Social Engineering"},
        {"x": 350,  "y": 720, "title": "Malware",       "icon": u"\U0001f4be",   "full": "Malware & Downloads"},
        {"x": 350,  "y": 540, "title": "Wi-Fi",         "icon": u"\U0001f4f6",   "full": "Public Wi-Fi Attack"},
        {"x": 1200, "y": 540, "title": "Ransomware",    "icon": u"\U0001f512",   "full": "Ransomware Response"},
        {"x": 1200, "y": 360, "title": "2FA",           "icon": u"\U0001f4f1",   "full": "Two-Factor Auth"},
        {"x": 350,  "y": 360, "title": "Safe Browse",   "icon": u"\U0001f310",   "full": "Safe Browsing"},
        {"x": 350,  "y": 180, "title": "Privacy",       "icon": u"\U0001f512",   "full": "Data Privacy"},
        {"x": 1200, "y": 180, "title": "Final Attack",  "icon": u"\u26a0\ufe0f", "full": "The Final Attack"},
    ]

    def _gen_path_dots(x1, y1, x2, y2, count=20):
        """Generate dots along a slightly curved path between two points."""
        dots = []
        dx = float(x2 - x1)
        dy = float(y2 - y1)
        length = math.sqrt(dx * dx + dy * dy)
        if length == 0:
            return [(x1, y1)]
        # Perpendicular direction for curve offset
        px = -dy / length
        py = dx / length
        for i in range(count + 1):
            t = float(i) / count
            cx = x1 + dx * t
            cy = y1 + dy * t
            # Sine wave offset for a gentle S-curve
            offset = math.sin(t * math.pi * 2) * 35
            cx += px * offset
            cy += py * offset
            dots.append((int(cx), int(cy)))
        return dots

    # Pre-generate all path segment dots
    _map_segments = []
    for _i in range(len(level_nodes) - 1):
        _n1 = level_nodes[_i]
        _n2 = level_nodes[_i + 1]
        _map_segments.append(_gen_path_dots(_n1["x"], _n1["y"], _n2["x"], _n2["y"], 22))

    def get_player_node():
        """Return 0-based index of the current (next playable) level."""
        if not store.level_1_done: return 0
        if not store.level_2_done: return 1
        if not store.level_3_done: return 2
        if not store.level_4_done: return 3
        if not store.level_5_done: return 4
        if not store.level_6_done: return 5
        if not store.level_7_done: return 6
        if not store.level_8_done: return 7
        if not store.level_9_done: return 8
        if not store.level_10_done: return 9
        return 10

    def can_play(lvl):
        """Check if a level (1-indexed) is currently playable."""
        if lvl == 1: return not store.level_1_done
        if lvl == 2: return store.level_1_done and not store.level_2_done
        if lvl == 3: return store.level_2_done and not store.level_3_done
        if lvl == 4: return store.level_3_done and not store.level_4_done
        if lvl == 5: return store.level_4_done and not store.level_5_done
        if lvl == 6: return store.level_5_done and not store.level_6_done
        if lvl == 7: return store.level_6_done and not store.level_7_done
        if lvl == 8: return store.level_7_done and not store.level_8_done
        if lvl == 9: return store.level_8_done and not store.level_9_done
        if lvl == 10: return store.level_9_done and not store.level_10_done
        return False

    def lvl_done(lvl):
        """Check if a level (1-indexed) is completed."""
        if lvl == 1: return store.level_1_done
        if lvl == 2: return store.level_2_done
        if lvl == 3: return store.level_3_done
        if lvl == 4: return store.level_4_done
        if lvl == 5: return store.level_5_done
        if lvl == 6: return store.level_6_done
        if lvl == 7: return store.level_7_done
        if lvl == 8: return store.level_8_done
        if lvl == 9: return store.level_9_done
        if lvl == 10: return store.level_10_done
        return False

# ── ATL Transforms ──

transform node_glow:
    zoom 1.0
    easein 0.6 zoom 1.1
    easeout 0.6 zoom 1.0
    repeat

transform node_completed_shine:
    alpha 0.85
    easein 1.0 alpha 1.0
    easeout 1.0 alpha 0.85
    repeat

transform player_bounce:
    yoffset 0
    easein 0.4 yoffset -10
    easeout 0.4 yoffset 0
    repeat

transform player_travel(sx, sy, tx, ty):
    anchor (0.5, 0.5)
    pos (sx, sy)
    ease 1.3 pos (tx, ty)

# ── Level Map Background (shared by interactive + animation screens) ──

screen level_map_bg():
    # ── Dark cyber background ──
    add Solid("#060c06")

    # ── Circuit-board grid ──
    for gx in range(0, 1921, 120):
        add Solid("#0d1a0d"):
            pos (gx, 0)
            xsize 1
            ysize 1080
    for gy in range(0, 1081, 120):
        add Solid("#0d1a0d"):
            pos (0, gy)
            xsize 1920
            ysize 1

    # ── Decorative corner brackets ──
    frame:
        pos (30, 30)
        xsize 80
        ysize 80
        padding (0, 0)
        background None
        add Solid("#00ff4422"):
            xsize 80
            ysize 3
        add Solid("#00ff4422"):
            xsize 3
            ysize 80

    frame:
        pos (1810, 30)
        xsize 80
        ysize 80
        padding (0, 0)
        background None
        add Solid("#00ff4422"):
            xsize 80
            ysize 3
            xalign 1.0
        add Solid("#00ff4422"):
            xsize 3
            ysize 80
            xalign 1.0

    # ── Draw path dots ──
    $ _pnode = get_player_node()
    for _seg_i in range(len(_map_segments)):
        for _dot in _map_segments[_seg_i]:
            frame:
                pos (_dot[0] - 5, _dot[1] - 5)
                xsize 10
                ysize 10
                padding (0, 0)
                if _seg_i < _pnode:
                    background Frame(Solid("#00cc66"), 5, 5)
                else:
                    background Frame(Solid("#1a3a1a"), 5, 5)

    # ── Draw level nodes ──
    for _ni in range(len(level_nodes)):
        $ _nd = level_nodes[_ni]
        $ _lv = _ni + 1
        $ _nx = _nd["x"]
        $ _ny = _nd["y"]
        $ _done = lvl_done(_lv)
        $ _play = can_play(_lv)

        if _done:
            # ── Completed node (Gold ring + checkmark) ──
            frame:
                pos (_nx - 48, _ny - 48)
                xsize 96
                ysize 96
                padding (0, 0)
                background Frame(Solid("#997700"), 48, 48)
                at node_completed_shine
                vbox:
                    xalign 0.5
                    yalign 0.5
                    spacing 0
                    text "✓" size 36 color "#ffffff" xalign 0.5
            # Level number badge
            frame:
                pos (_nx + 30, _ny - 55)
                xsize 32
                ysize 32
                padding (0, 0)
                background Frame(Solid("#ddaa00"), 16, 16)
                text str(_lv) size 16 color "#ffffff" xalign 0.5 yalign 0.5 bold True
            # Label
            text _nd["title"]:
                pos (_nx, _ny + 56)
                anchor (0.5, 0.0)
                size 17
                color "#ccaa33"

        elif _play:
            # ── Active node (Green, pulsing) — drawn but NOT clickable here ──
            frame:
                pos (_nx - 55, _ny - 55)
                xsize 110
                ysize 110
                padding (0, 0)
                background Frame(Solid("#00cc44"), 55, 55)
                at node_glow
                vbox:
                    xalign 0.5
                    yalign 0.5
                    spacing 2
                    text _nd["icon"] size 36 xalign 0.5
            # Level number badge
            frame:
                pos (_nx + 35, _ny - 62)
                xsize 36
                ysize 36
                padding (0, 0)
                background Frame(Solid("#00ff66"), 18, 18)
                text str(_lv) size 18 color "#003311" xalign 0.5 yalign 0.5 bold True
            # Label
            text ("{b}" + _nd["title"] + "{/b}"):
                pos (_nx, _ny + 64)
                anchor (0.5, 0.0)
                size 19
                color "#00ff66"

        else:
            # ── Locked node (Grey + lock) ──
            frame:
                pos (_nx - 42, _ny - 42)
                xsize 84
                ysize 84
                padding (0, 0)
                background Frame(Solid("#252525"), 42, 42)
                vbox:
                    xalign 0.5
                    yalign 0.5
                    spacing 2
                    text "🔒" size 26 xalign 0.5
            # Level number badge
            frame:
                pos (_nx + 25, _ny - 48)
                xsize 28
                ysize 28
                padding (0, 0)
                background Frame(Solid("#444444"), 14, 14)
                text str(_lv) size 13 color "#888888" xalign 0.5 yalign 0.5
            # Label
            text _nd["title"]:
                pos (_nx, _ny + 48)
                anchor (0.5, 0.0)
                size 14
                color "#444444"

    # ── Final Report node (top center) ──
    if store.level_10_done:
        # Path dots from node 10 to final report
        for _fdot in _gen_path_dots(1200, 180, 1200, 55, 6):
            frame:
                pos (_fdot[0] - 4, _fdot[1] - 4)
                xsize 8
                ysize 8
                padding (0, 0)
                background Frame(Solid("#cc6600"), 4, 4)


# ── Fixed UI Banners (shared) ──
screen level_map_ui_overlays():
    # ── Title Banner ──
    frame:
        xalign 0.5
        ypos 20
        padding (50, 14)
        background Frame(Solid("#001a0088"), 12, 12)
        hbox:
            spacing 14
            text "🛡" size 30 yalign 0.5
            text "CYBERSEC MASTERY" size 30 color "#00ff99" bold True yalign 0.5
            text "—" size 24 color "#336633" yalign 0.5
            text "SELECT YOUR MISSION" size 24 color "#66cc88" yalign 0.5

# ── Interactive Level Map Screen ──

screen level_map_screen():
    modal True
    tag menu
    
    $ _cur = get_player_node()
    
    # Calculate initial scroll based on current node
    python:
        if _cur < len(level_nodes):
            _scroll_x = level_nodes[_cur]["x"] / 1920.0
            _scroll_y = level_nodes[_cur]["y"] / 1080.0
        else:
            _scroll_x = 0.5
            _scroll_y = 0.0

    # ── Scrollable Map Canvas ──
    viewport:
        id "map_vp"
        edgescroll (150, 400)
        draggable True
        scrollbars None
        xinitial _scroll_x
        yinitial _scroll_y
        
        fixed:
            xsize 1920
            ysize 1080

            use level_map_bg

            # ── Clickable overlay on the active (playable) node ──
            if _cur < len(level_nodes):
                $ _cn = level_nodes[_cur]
                button:
                    pos (_cn["x"] - 55, _cn["y"] - 55)
                    xsize 110
                    ysize 110
                    background None
                    hover_background Frame(Solid("#00ff6633"), 55, 55)
                    action Return(_cur + 1)

            # ── Player marker (shield icon bouncing above current node) ──
            if _cur < len(level_nodes):
                $ _px = level_nodes[_cur]["x"]
                $ _py = level_nodes[_cur]["y"]
                frame:
                    pos (_px - 24, _py - 95)
                    xsize 48
                    ysize 48
                    padding (0, 0)
                    background None
                    at player_bounce
                    text "🛡" size 38 xalign 0.5 yalign 0.5

    # ── Fixed Screen Overlays ──
    use level_map_ui_overlays

    # ── Final Report button ──
    if store.level_10_done:
        button:
            pos (1080, 80)
            xsize 240
            ysize 55
            background Frame(Solid("#cc6600cc"), 10, 10)
            hover_background Frame(Solid("#ff8800cc"), 10, 10)
            at node_glow
            text "📊 FINAL REPORT" size 20 color "#ffffff" xalign 0.5 yalign 0.5 bold True
            action Return("report")

    # ── Bottom info bar ──
    frame:
        xalign 0.5
        yalign 0.97
        padding (25, 8)
        background Frame(Solid("#00000088"), 8, 8)
        if _cur < len(level_nodes):
            text ("▶ Drag to scroll. Click the glowing node to begin: {b}" + level_nodes[_cur]["full"] + "{/b}"):
                size 20
                color "#88ffaa"
        else:
            text "🏆 All missions complete! View your Final Report above.":
                size 20
                color "#ffcc66"


# ── Travel Animation Screen (player icon moves along the path) ──

screen level_travel_anim(from_x, from_y, to_x, to_y, level_name):
    modal True

    python:
        _scroll_x = from_x / 1920.0
        _scroll_y = from_y / 1080.0

    viewport:
        id "anim_vp"
        edgescroll None
        draggable False
        scrollbars None
        xinitial _scroll_x
        yinitial _scroll_y
        
        fixed:
            xsize 1920
            ysize 1080

            use level_map_bg

            # ── Moving player shield ──
            text "🛡":
                size 52
                at player_travel(from_x, from_y, to_x, to_y)

    use level_map_ui_overlays

    # ── "Heading to..." overlay ──
    frame:
        xalign 0.5
        yalign 0.88
        padding (40, 14)
        background Frame(Solid("#001a00cc"), 10, 10)
        hbox:
            spacing 10
            text "▶▶" size 24 color "#00ff66" yalign 0.5
            text ("DEPLOYING TO: {b}" + level_name + "{/b}"):
                size 26
                color "#00ffaa"
                yalign 0.5

    # Auto-advance after animation completes
    timer 1.6 action Return()



# ═══════════════════════════════════════════════════════════════
#  GAME START
# ═══════════════════════════════════════════════════════════════

label start:
    $ requested_level = get_web_level()
    if requested_level == 1:
        jump level_1
    elif requested_level == 2:
        jump level_2
    elif requested_level == 3:
        jump level_3
    elif requested_level == 4:
        jump level_4
    elif requested_level == 5:
        jump level_5
    elif requested_level == 6:
        jump level_6
    elif requested_level == 7:
        jump level_7
    elif requested_level == 8:
        jump level_8
    elif requested_level == 9:
        jump level_9
    elif requested_level == 10:
        jump level_10

    # Standard Desktop Start:
    show screen secure_bar_display
    scene bg_office with fade

    "Welcome to {b}CyberSec Mastery{/b} — a cybersecurity awareness simulation."
    "Navigate real-world cyber threats across {b}10 immersive levels{/b}."
    "Your decisions will shape the outcome. Every choice affects your {color=#00ff99}System Integrity{/color} score."
    "Let's begin."

    jump level_select

label level_select:
    # Hide the secure bar temporarily on the map view
    hide screen secure_bar_display

    # Show the interactive level map
    call screen level_map_screen
    $ _selected = _return

    if _selected == "report":
        show screen secure_bar_display
        jump ending

    # Calculate travel animation positions
    $ _from_idx = get_player_node()
    $ _to_idx = _selected - 1
    $ _from_x = level_nodes[min(_from_idx, 9)]["x"]
    $ _from_y = level_nodes[min(_from_idx, 9)]["y"]
    $ _to_x = level_nodes[_to_idx]["x"]
    $ _to_y = level_nodes[_to_idx]["y"]
    $ _to_name = level_nodes[_to_idx]["full"]

    # Play movement animation
    call screen level_travel_anim(_from_x, _from_y, _to_x, _to_y, _to_name)

    # Re-show secure bar for gameplay
    show screen secure_bar_display

    # Jump to the selected level
    if _selected == 1:
        jump level_1
    elif _selected == 2:
        jump level_2
    elif _selected == 3:
        jump level_3
    elif _selected == 4:
        jump level_4
    elif _selected == 5:
        jump level_5
    elif _selected == 6:
        jump level_6
    elif _selected == 7:
        jump level_7
    elif _selected == 8:
        jump level_8
    elif _selected == 9:
        jump level_9
    elif _selected == 10:
        jump level_10


# ═══════════════════════════════════════════════════════════════
#  LEVEL 1: THE SUSPICIOUS EMAIL (Phishing Awareness)
# ═══════════════════════════════════════════════════════════════

label level_1:
    scene bg_office with dissolve
    show arjun at left with easeinright

    sys "━━━ LEVEL 1: THE SUSPICIOUS EMAIL ━━━"
    "You are {b}Arjun{/b}, a corporate analyst at CyberSafe Solutions."
    "It's Monday morning. Your inbox has a new message."

    arj "Another week, another mountain of emails. Let me check what's urgent..."

    "Arjun pulls out his phone and sees a notification..."

    $ email_choice = renpy.call_screen("email_phone_screen")

    if email_choice == "inspect":
        arj "Wait... 'cybersafe-helpdesk.net'? Our actual domain is cybersafe.com. This doesn't match."
        "Arjun notices the sender domain is suspicious."

        menu:
            "Report it as phishing to the IT team":
                $ secure_bar = min(100, secure_bar + 10)
                show arjun at left with dissolve
                arj "I'm forwarding this to IT Security right now. This is a phishing attempt."
                sys "✅ Phishing email reported and quarantined. Excellent awareness!"
                "The IT team confirms this was a targeted phishing campaign. Arjun's report helped protect the entire company."

            "Click the link to check — maybe it's real":
                $ secure_bar = max(0, secure_bar - 20)
                "Arjun clicks the link. A login page appears that looks like the company portal..."
                arj "Hmm, the URL says 'cybersafe-helpdesk.net/login'... but everything looks official."
                "He enters his credentials."
                show arjun at left with dissolve
                hacker "Got your login. Thanks for the free access. 😈"
                sys "⚠️ CREDENTIAL COMPROMISE DETECTED. Your password has been stolen!"
                "Never enter credentials on unverified websites. Always check the URL carefully."

    elif email_choice == "delete":
        arj "This looks suspicious. I'll just delete it."
        "A safe instinct, but the IT team could have used a report to protect others."
        "Deleting without reporting means other employees might still fall for it."

    elif email_choice == "click":
        $ secure_bar = max(0, secure_bar - 25)
        "In a panic, Arjun taps the link and enters his credentials."
        show arjun at left with dissolve
        hacker "Too easy. Urgency is our best weapon. 😈"
        sys "🚨 ACCOUNT COMPROMISED! The hacker used urgency to bypass your judgment."
        "Attackers create false urgency to make you act before you think."

    hide arjun with dissolve
    $ level_1_done = True
    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    "{i}Level 1 Complete — Key Lesson: Always verify sender domains and never click links in suspicious emails.{/i}"
    $ post_level_done(1)
    jump level_select


# ═══════════════════════════════════════════════════════════════
#  LEVEL 2: PASSWORD SECURITY
# ═══════════════════════════════════════════════════════════════

label level_2:
    scene bg_school with dissolve

    sys "━━━ LEVEL 2: PASSWORD SECURITY ━━━"
    "A university cybersecurity lab. {b}Prof. Meera{/b} is teaching her students about password safety."

    show prof_meera at center with easeinbottom
    meera "Good morning, class. Today we're going to see just how vulnerable weak passwords are."
    meera "I've set up a simulated brute-force attack. Let's see how fast common passwords can be cracked."

    show rahul at left with easeinleft
    show ananya at right with easeinright

    rah "Brute force? That sounds intense."
    ana "Is it really that fast?"

    meera "Let me show you. Watch the screen..."

    call screen brute_force_demo

    meera "As you just saw, the password 'password' was cracked in {b}0.3 seconds{/b}."
    meera "Now, here's today's challenge. I want each of you to create a password for the lab system."

    hide prof_meera with dissolve
    hide ananya with dissolve

    "It's Rahul's turn first."
    rah "Alright, I need to pick a password..."

    menu:
        "Help Rahul choose a password:"

        "Use: MyD0g$Name2024! (long, mixed chars)":
            $ secure_bar = min(100, secure_bar + 15)
            show rahul at left with dissolve
            rah "Done! 16 characters, uppercase, lowercase, numbers, and symbols."
            show prof_meera at center with dissolve
            meera "Excellent! That would take centuries to brute-force. Well done, Rahul."
            hide prof_meera with dissolve

        "Use: rahul123 (easy to remember)":
            $ secure_bar = max(0, secure_bar - 15)
            show rahul at left with dissolve
            rah "Simple and easy to remember!"
            show prof_meera at center with dissolve
            meera "Rahul... that's your name followed by '123'. A dictionary attack would crack this instantly."
            meera "Never use personal information in passwords."
            hide prof_meera with dissolve

        "Use: password (classic)":
            $ secure_bar = max(0, secure_bar - 20)
            show rahul at left with dissolve
            rah "You know what, 'password' is easy to remember."
            show prof_meera at center with dissolve
            meera "Rahul. We literally just watched that get cracked in 0.3 seconds."
            meera "Please tell me you're joking."
            rah "...I'll change it."
            hide prof_meera with dissolve

    hide rahul with dissolve
    show ananya at center with dissolve

    "Now it's Ananya's turn."
    ana "Professor, should I enable two-factor authentication too?"

    menu:
        "What should Ananya do?"

        "Yes — enable 2FA with an authenticator app":
            $ secure_bar = min(100, secure_bar + 10)
            show ananya at center with dissolve
            ana "Done! Even if someone guesses my password, they'd need my phone to log in."
            show prof_meera at right with dissolve
            meera "That's the gold standard. Password + 2FA = very strong security."
            hide prof_meera with dissolve

        "No — a strong password is enough":
            show ananya at center with dissolve
            ana "I think my password alone is fine."
            show prof_meera at right with dissolve
            meera "A strong password is good, but 2FA adds a critical second layer. Always enable it when available."
            hide prof_meera with dissolve

    hide ananya with dissolve

    $ level_2_done = True
    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    "{i}Level 2 Complete — Key Lesson: Use long, complex passwords and always enable two-factor authentication.{/i}"
    $ post_level_done(2)
    jump level_select


# ═══════════════════════════════════════════════════════════════
#  LEVEL 3: SOCIAL ENGINEERING (Vishing Attack)
# ═══════════════════════════════════════════════════════════════

label level_3:
    scene bg_bank with dissolve

    sys "━━━ LEVEL 3: SOCIAL ENGINEERING ━━━"
    "You are {b}Riya{/b}, a young professional. You just received a phone call..."

    show riya at center with easeinbottom

    riy "I'm not expecting any calls. Let me check who this is..."

    $ phone_result = renpy.call_screen("phone_popup")

    if phone_result == "decline":
        $ secure_bar = min(100, secure_bar + 5)
        riy "I don't recognize this number. I'll let it go to voicemail."
        "The call goes to voicemail. No message is left."
        riy "If it's really the bank, they'll leave a message or I can call them directly."

        "Smart move. But let's see what would have happened if Riya had answered..."
        "For educational purposes, let's explore the scenario:"

    riy "Hello?"

    show fake_caller at right with easeinright
    caller "Good afternoon, ma'am. This is Rajesh from National Secure Bank's Fraud Prevention Unit."
    caller "We've detected suspicious activity on your account ending in ****7842."
    caller "For your protection, we need to verify your identity immediately."

    riy "Suspicious activity? What kind?"

    caller "Someone attempted a ₹50,000 transfer from your account to an overseas account."
    caller "We've temporarily blocked it, but we need your OTP to confirm the block."

    menu:
        "How does Riya respond?"

        "\"My bank would never ask for an OTP over the phone.\"":
            $ secure_bar = min(100, secure_bar + 15)
            riy "I know my bank's policy. They never ask for OTPs or passwords over the phone."
            riy "If there's really suspicious activity, I'll call the number on the back of my card."

            caller "Ma'am, this is urgent! If you don't verify now—"

            riy "I'm hanging up. Goodbye."
            hide fake_caller with dissolve

            sys "✅ Riya avoided a vishing attack! She knew that real banks never ask for OTPs over the phone."
            show riya at center with dissolve
            "Riya calls her bank directly and confirms there was no suspicious activity."
            "The call was a classic {b}vishing{/b} (voice phishing) attack."

        "Provide the OTP — the situation sounds urgent":
            $ secure_bar = max(0, secure_bar - 20)
            $ gave_otp = True

            riy "Okay... the OTP I just received is 847293."

            caller "Thank you, ma'am. Your account is now secured. Have a nice day."
            hide fake_caller with dissolve

            "Moments later..."
            sys "🚨 ALERT: ₹50,000 debited from your account!"
            show riya at center with dissolve
            riy "What?! But he said he was blocking the transfer!"

            "The 'bank officer' was a scammer. The OTP authorized a real transfer."
            "Banks will {b}never{/b} ask for your OTP over the phone. The OTP is meant to confirm {i}your{/i} actions, not theirs."

        "Ask for his employee ID and call back the bank":
            $ secure_bar = min(100, secure_bar + 10)
            riy "Can you give me your employee ID? I'll call the bank's official number to verify."

            caller "Ma'am, by the time you call back, the transfer will go through—"

            riy "If it's a real emergency, my bank can handle it when I call them. What's your ID?"

            "The caller hesitates and hangs up."
            hide fake_caller with dissolve

            sys "✅ The scammer couldn't provide credentials and disconnected."
            show riya at center with dissolve
            "Always verify by calling the official number — never trust incoming calls about 'urgent' financial matters."

    hide riya with dissolve

    $ level_3_done = True
    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    "{i}Level 3 Complete — Key Lesson: Never share OTPs or passwords over the phone. Always call your bank directly.{/i}"
    $ post_level_done(3)
    jump level_select


# ═══════════════════════════════════════════════════════════════
#  LEVEL 4: MALWARE & DOWNLOADS
# ═══════════════════════════════════════════════════════════════

label level_4:
    scene bg_home with dissolve

    sys "━━━ LEVEL 4: MALWARE & DOWNLOADS ━━━"
    "You are {b}Vikram{/b}, a college student looking for a free code editor."

    show vikram at center with easeinbottom

    vik "I need a code editor for my project. Let me search online..."
    vik "Here's one: 'SuperCodeEditor v3.1 — Free Download!' on some random site."

    menu:
        "What does Vikram do?"

        "Download from the official website instead":
            $ secure_bar = min(100, secure_bar + 10)
            show vikram at center with dissolve
            vik "Actually, let me go to the official site instead. Random download sites can bundle malware."
            "Vikram finds the official SuperCodeEditor site and downloads the verified installer."
            sys "✅ Safe download from the official source. No bundled malware."
            "Always download software from official websites or trusted app stores."
            jump level_4_end

        "Download from the sketchy site — it's free!":
            vik "Free is free! Downloading now..."
            "The download completes. Vikram runs the installer."
            jump level_4_installer

        "Search for a cracked/pirated version":
            $ secure_bar = max(0, secure_bar - 15)
            vik "Why pay when I can find a cracked version?"
            "Vikram downloads a 'cracked' version from a torrent site."
            show vikram at center with dissolve
            sys "🚨 WARNING: The cracked installer contained a {b}keylogger{/b}!"
            sys "Every password Vikram types is now being recorded and sent to an attacker."
            "Pirated software is one of the most common malware delivery methods."
            "Vikram's bank password, email password, and social media accounts are all compromised."
            $ secure_bar = max(0, secure_bar - 10)
            jump level_4_end

    label level_4_installer:
        "The installer wizard appears..."

        $ installer_result = renpy.call_screen("installer_ui")

        if installer_result == "cancel":
            $ secure_bar = min(100, secure_bar + 5)
            vik "On second thought, I should probably get this from the official site."
            "Good instinct. Cancelling suspicious installers is always safe."

        elif installer_result == True:
            $ secure_bar = max(0, secure_bar - 15)
            $ installed_toolbar = True
            vik "Installation complete!"
            "But wait — the browser opens to a strange search engine."
            show vikram at center with dissolve
            sys "⚠️ BonusSearchToolbar™ has been installed!"
            sys "Your browser homepage has been changed. Your search queries are being tracked."
            vik "What?! I didn't want this toolbar!"
            "The checkbox was pre-checked. Always read every option during installation."
            "Bundled software (PUPs — Potentially Unwanted Programs) is a common trick."

        else:
            $ secure_bar = min(100, secure_bar + 10)
            show vikram at center with dissolve
            vik "Wait — I unchecked that toolbar thing. Good thing I was paying attention."
            "Installation complete — without any bundled malware."
            sys "✅ Vikram avoided the bundled toolbar by reading the installer carefully."
            "Always uncheck extra software offers during installation."

    label level_4_end:
        hide vikram with dissolve

        $ level_4_done = True
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        "{i}Level 4 Complete — Key Lesson: Only download from official sources. Read every checkbox in installers carefully.{/i}"
        $ post_level_done(4)
    jump level_select


# ═══════════════════════════════════════════════════════════════
#  LEVEL 5: PUBLIC WI-FI ATTACK (Evil Twin)
# ═══════════════════════════════════════════════════════════════

label level_5:
    scene bg_campus with dissolve

    sys "━━━ LEVEL 5: PUBLIC WI-FI ATTACK ━━━"
    "You are {b}Naveen{/b}, a freelancer working from Bean & Brew café."

    show naveen at center with easeinbottom

    nav "Great coffee, good vibes. Let me connect to Wi-Fi and get some work done."
    nav "Let me check the available networks..."

    $ wifi_result = renpy.call_screen("wifi_selection")

    if wifi_result == "evil_twin":
        $ secure_bar = max(0, secure_bar - 20)
        $ chose_evil_wifi = True

        nav "Nice, 'BeanAndBrew_FreeWiFi' — full signal and no password needed!"
        "Naveen connects to the open network and starts working."

        "30 minutes later..."
        nav "Let me quickly check my bank balance..."
        "Naveen logs into his bank's website."

        hacker "Beautiful. Unencrypted traffic on my Evil Twin hotspot. I can see everything."
        show naveen at center with dissolve
        sys "🚨 MAN-IN-THE-MIDDLE ATTACK DETECTED!"
        sys "The 'BeanAndBrew_FreeWiFi' network was a fake hotspot set up by an attacker."
        sys "All unencrypted data — including login credentials — has been intercepted."

        "The real café network was 'BeanAndBrew_Guest' (the WPA2-protected one)."
        "Evil Twin attacks create fake open hotspots that mimic legitimate networks."

        menu:
            "Naveen realizes something is wrong. What now?"

            "Disconnect immediately and change all passwords":
                $ secure_bar = min(100, secure_bar + 10)
                nav "Something feels off. I'm disconnecting NOW."
                "Naveen disconnects, switches to mobile data, and changes his passwords."
                sys "Damage control: passwords changed before the attacker could use them."

            "Keep using the Wi-Fi — it's probably fine":
                $ secure_bar = max(0, secure_bar - 10)
                nav "I'm sure it's fine. The internet is working."
                "The hacker continues capturing data for the next hour."
                sys "Multiple account credentials compromised."

    elif wifi_result == "legit":
        $ secure_bar = min(100, secure_bar + 15)
        nav "I'll go with 'BeanAndBrew_Guest' — it needs a password so it's encrypted."
        "Naveen asks the barista for the Wi-Fi password."
        "The barista confirms: 'BeanAndBrew_Guest' is the official network."

        sys "✅ Naveen connected to the legitimate, encrypted network."
        show naveen at center with dissolve
        nav "WPA2 encryption means my traffic is protected from casual eavesdropping."

        "But Naveen also takes an extra precaution..."

        menu:
            "Should Naveen use a VPN while on public Wi-Fi?"

            "Yes — turn on a VPN for extra protection":
                $ secure_bar = min(100, secure_bar + 5)
                nav "Even on encrypted Wi-Fi, a VPN adds another layer of security."
                sys "✅ VPN activated. All traffic is now encrypted end-to-end."

            "No — WPA2 is enough":
                nav "WPA2 should be sufficient for now."
                "WPA2 provides basic encryption, but a VPN would protect against more sophisticated attacks."

    else:
        nav "That network doesn't belong here. I'll look for the café's actual Wi-Fi."
        "Naveen asks the barista and connects to the correct network."

    hide naveen with dissolve

    $ level_5_done = True
    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    "{i}Level 5 Complete — Key Lesson: Avoid open Wi-Fi networks. Use WPA2/WPA3 networks and a VPN for public connections.{/i}"
    $ post_level_done(5)
    jump level_select


# ═══════════════════════════════════════════════════════════════
#  LEVEL 6: RANSOMWARE RESPONSE
# ═══════════════════════════════════════════════════════════════

label level_6:
    scene bg_office with fade
    sys "━━━ LEVEL 6: RANSOMWARE RESPONSE ━━━"
    "You are Sanjay. You're working late when suddenly..."
    
    show sanjay at center with dissolve
    sys "🚨 ALERT: YOUR FILES HAVE BEEN ENCRYPTED!"
    "A massive red window pops up on your screen."
    "Hacker: 'Pay 0.5 Bitcoin ($15,000) within 48 hours or lose everything.'"

    menu:
        "What should Sanjay do?"

        "Pay the ransom to get files back!":
            $ secure_bar = max(0, secure_bar - 30)
            show hacker at center with dissolve
            hacker "Payment received... Just kidding, your files are still encrypted. Thanks for the money!"
            sys "⚠️ WARNING: Paying doesn't guarantee access and only funds further crime."
            jump level_6_disconnect

        "Don't pay. Disconnect from the network.":
            $ secure_bar = min(100, secure_bar + 20)
            san "I'm not paying. I need to isolate this machine right now."
            "Sanjay pulls the ethernet cable and disables Wi-Fi."
            jump level_6_disconnect

        "Try to negotiate a lower ransom":
            $ secure_bar = max(0, secure_bar - 15)
            sys "While you were sub negotiating, the malware spread to other devices on your network."
            san "Oh no! It's spreading! I have to disconnect!"
            jump level_6_disconnect

label level_6_disconnect:
    hide hacker
    show sanjay at center with dissolve
    san "Okay, I've disconnected. Now I need to see if I can recover my work."

    menu:
        "Does Sanjay have backups?"

        "Yes! Last week's external backup.":
            $ secure_bar = min(100, secure_bar + 20)
            sys "✅ Excellent! Sanjay restored from an offline backup. No data was lost."
            san "Thank goodness I kept that drive unplugged!"

        "No... I never set up backups.":
            $ secure_bar = max(0, secure_bar - 20)
            sys "🚨 CRITICAL LOSS: Without backups, the encrypted files are permanently lost."
            san "All those months of work... gone."

    hide sanjay with dissolve
    $ level_6_done = True
    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    "{i}Level 6 Complete — Key Lesson: Never pay the ransom. Maintain regular, offline backups of your important data.{/i}"
    $ post_level_done(6)
    jump level_select


# ═══════════════════════════════════════════════════════════════
#  LEVEL 7: TWO-FACTOR AUTH
# ═══════════════════════════════════════════════════════════════

label level_7:
    scene bg_home with fade
    sys "━━━ LEVEL 7: TWO-FACTOR AUTH ━━━"
    "You are Kavita. You're reviewing your account security settings."

    show kavita at center with dissolve
    kav "My password is strong, but is it enough? Should I enable 2FA?"

    menu:
        "Enable Two-Factor Authentication (2FA)?"

        "Yes, let's set it up!":
            $ secure_bar = min(100, secure_bar + 15)
            kav "Better safe than sorry. Let's see my options."
            jump level_7_methods

        "Nah, my password is strong enough.":
            $ secure_bar = max(0, secure_bar - 20)
            "A week later..."
            sys "🚨 ALERT: Your account was accessed from an unknown location in Eastern Europe."
            kav "What?! But my password was 'K@v1t4_S3cur3'!"
            sys "Your password was leaked in a third-party data breach. Without 2FA, the hacker got right in."
            kav "I should have enabled it when I had the chance."
            jump level_7_methods

label level_7_methods:
    show kavita at center with dissolve
    kav "Okay, which 2FA method is best?"

    menu:
        "Choose a 2FA method:"

        "SMS Text Code":
            $ secure_bar = min(100, secure_bar + 10)
            sys "✅ SMS 2FA enabled! A good start, but be aware of SIM-swapping risks."
        
        "Authenticator App":
            $ secure_bar = min(100, secure_bar + 20)
            sys "✅ Excellent! Authenticator apps generate codes locally, which is much more secure than SMS."

        "Hardware Security Key":
            $ secure_bar = min(100, secure_bar + 20)
            sys "✅ Best! A physical security key (like YubiKey) is the gold standard of 2FA."

    hide kavita with dissolve
    $ level_7_done = True
    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    "{i}Level 7 Complete — Key Lesson: Always enable 2FA. It provides a critical second layer of defense if your password is stolen.{/i}"
    $ post_level_done(7)
    jump level_select


# ═══════════════════════════════════════════════════════════════
#  LEVEL 8: SAFE BROWSING
# ═══════════════════════════════════════════════════════════════

label level_8:
    scene bg_cafe with fade
    sys "━━━ LEVEL 8: SAFE BROWSING ━━━"
    "You are Zoe. You need to buy a textbook for your upcoming exam."

    show zoe at center with dissolve
    zoe "I found a few sites selling the book. Which one should I trust?"

    menu:
        "Choose a website to visit:"

        "www.amaz0n-discount.com (HTTP)":
            $ secure_bar = max(0, secure_bar - 20)
            sys "🚨 PHISHING ALERT: This is a clone website designed to steal credit card info."
            zoe "Wait, the URL looks a bit off... amaz-ZE-RO-n?"
            "Zoe leaves the site before entering any info."
            jump level_8_secure

        "www.amazon.com/books (HTTPS 🔒)":
            $ secure_bar = min(100, secure_bar + 20)
            sys "✅ Safe choice. You're on the official site with a valid HTTPS certificate."
            jump level_8_secure

        "www.free-books.xyz":
            $ secure_bar = max(0, secure_bar - 15)
            sys "⚠️ MALWARE ALERT: The site is full of intrusive pop-ups and fake download buttons."
            zoe "I'm getting out of here. It feels sketchy."
            jump level_8_secure

label level_8_secure:
    scene bg_home
    show zoe at center with dissolve
    "While browsing the legitimate site, a pop-up appears:"
    "{b}SPECIAL OFFER! Download our new 'CyberSavings' desktop app for 50%% off your order!{/b}"

    menu:
        "What should Zoe do?"

        "Download the app!":
            $ secure_bar = max(0, secure_bar - 20)
            sys "🚨 MALWARE DETECTED: That was a fake pop-up. The 'CyberSavings' app was actually adware."
            zoe "I shouldn't have clicked that. My browser is now full of ads."

        "Ignore the pop-up":
            $ secure_bar = min(100, secure_bar + 15)
            sys "✅ Wise choice! You avoided a 'malvertising' trap."

    hide zoe with dissolve
    $ level_8_done = True
    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    "{i}Level 8 Complete — Key Lesson: Always check URLs carefully and stick to HTTPS sites. Avoid downloading software from unexpected pop-ups.{/i}"
    $ post_level_done(8)
    jump level_select


# ═══════════════════════════════════════════════════════════════
#  LEVEL 9: DATA PRIVACY
# ═══════════════════════════════════════════════════════════════

label level_9:
    scene bg_mall with fade
    sys "━━━ LEVEL 9: DATA PRIVACY ━━━"
    "You are Dr. Amit. You're setting up a new professional networking app."

    show amit at center with dissolve
    ami "The app is asking for permissions. It wants access to everything."

    menu:
        "Manage app permissions:"

        "Allow ALL (camera, contacts, location, mic)":
            $ secure_bar = max(0, secure_bar - 20)
            sys "🚨 PRIVACY BREACH: The app is now quietly uploading your contacts and tracking your location 24/7."
            ami "That seems excessive for a networking app. I should change this."
            jump level_9_smart

        "Allow only what's needed":
            $ secure_bar = min(100, secure_bar + 20)
            ami "I'll only grant access as I use the features. Much safer."
            jump level_9_smart

label level_9_smart:
    show amit at center with dissolve
    ami "Now for my profile. How much information should I make public?"

    menu:
        "Set profile visibility:"

        "Public: Name, school, birthday, address, phone":
            $ secure_bar = max(0, secure_bar - 20)
            sys "🚨 OVERSHARING: A stranger has already used your info to find your home address."
            ami "I need to hide these details immediately."
            jump level_9_privacy

        "Private: First name only, minimal professional details":
            $ secure_bar = min(100, secure_bar + 20)
            sys "✅ Smart! You've minimized your digital footprint."
            jump level_9_privacy

label level_9_privacy:
    show amit at center with dissolve
    ami "One last thing: Who can see my posts?"

    menu:
        "Set post audience:"

        "Everyone (Public)":
            $ secure_bar = max(0, secure_bar - 10)
            sys "⚠️ Your posts are visible to the entire internet, including potential attackers."

        "Connections Only (Private)":
            $ secure_bar = min(100, secure_bar + 15)
            sys "✅ Safer! Your content is restricted to people you've approved."

    hide amit with dissolve
    $ level_9_done = True
    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    "{i}Level 9 Complete — Key Lesson: Practice 'Least Privilege' with app permissions and 'Minimal Disclosure' on public profiles.{/i}"
    $ post_level_done(9)
    jump level_select


# ═══════════════════════════════════════════════════════════════
#  LEVEL 10: THE FINAL ATTACK
# ═══════════════════════════════════════════════════════════════

label level_10:
    scene bg_server_room with fade
    sys "━━━ LEVEL 10: THE FINAL ATTACK ━━━"
    "You are Maya, the Chief Information Security Officer (CISO)."

    show maya at center with dissolve
    sys "🚨 COORDINATED ATTACK DETECTED! Multiple threats are emerging simultaneously."
    may "This is it. I need to make the right calls to protect the firm."

    menu:
        "THREAT 1: Urgent email from the CEO: 'Wire $50,000 to the following account immediately for a confidential merger.'"

        "Wire the money — it sounds urgent!":
            $ secure_bar = max(0, secure_bar - 20)
            sys "🚨 CEO FRAUD: You've just sent $50,000 to a criminal syndicate."
            may "I should have verified that first."

        "Call the CEO directly to verify":
            $ secure_bar = min(100, secure_bar + 20)
            "The CEO confirms they never sent the email."
            sys "✅ Threat Neutralized! You spotted a 'Business Email Compromise' attack."

    may "Next threat..."

    menu:
        "THREAT 2: Files on the central server are being encrypted in real-time!"

        "Pay the ransom quickly to stop the encryption!":
            $ secure_bar = max(0, secure_bar - 20)
            show hacker at center with dissolve
            hacker "Thanks for the payment! But we're keeping your files locked anyway."
            may "I've just funded my own attackers."
            hide hacker

        "Disconnect systems and restore from offline backups":
            $ secure_bar = min(100, secure_bar + 20)
            sys "✅ Ransomware Contained! The damage was limited and recovery is underway."

    may "One final challenge..."

    menu:
        "THREAT 3: A 'technician' is at the lobby demanding server room access for an 'emergency fix'. They have no official ID."

        "Let them in — it sounds like a critical emergency!":
            $ secure_bar = max(0, secure_bar - 20)
            sys "🚨 PHYSICAL BREACH: The 'technician' has installed keyloggers on the main server console."
            may "I let an imposter walk right in."

        "Refuse entry and call HR to verify the appointment":
            $ secure_bar = min(100, secure_bar + 20)
            "The 'technician' flees as soon as you pick up the phone."
            sys "✅ Security Maintained! You prevented a physical infiltration."

    may "VICTORY! We've navigated the storm. Cybersecurity is a team effort."
    
    hide maya with dissolve
    $ level_10_done = True
    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    "{size=+5}GAME COMPLETE! Your final evaluation awaits.{/size}"
    $ post_level_done(10)
    jump ending


# ═══════════════════════════════════════════════════════════════
#  ENDING: FINAL EVALUATION
# ═══════════════════════════════════════════════════════════════

label ending:
    scene bg_office with fade

    sys "━━━ FINAL EVALUATION ━━━"
    "All 10 levels complete. Your cybersecurity awareness has been tested."
    "Let's review your {b}System Integrity{/b} score."

    show office_team at center with dissolve

    if secure_bar >= 80:
        show office_team at center with dissolve
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        "{size=+10}{color=#00ff99}{b}🏆 CYBER DEFENDER — OUTSTANDING!{/b}{/color}{/size}"
        "System Integrity: {color=#00ff99}[secure_bar]%%{/color}"
        ""
        "You demonstrated exceptional cybersecurity awareness across all scenarios."
        "You identified phishing attempts, created strong passwords, resisted social engineering,"
        "avoided malware, and navigated public Wi-Fi safely."
        ""
        "{i}The digital world needs more people like you. Stay vigilant!{/i}"

    elif secure_bar >= 60:
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        "{size=+10}{color=#66ccff}{b}🛡 SECURITY AWARE — GOOD JOB!{/b}{/color}{/size}"
        "System Integrity: {color=#66ccff}[secure_bar]%%{/color}"
        ""
        "You made mostly good decisions, but there's room for improvement."
        "A few risky choices put data at risk."
        ""
        show family at center with dissolve
        "{i}Review the levels where you struggled and try again for a perfect score!{/i}"

    elif secure_bar >= 40:
        show office_team at center with dissolve
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        "{size=+10}{color=#ffcc00}{b}⚠ PARTIALLY SECURE — NEEDS WORK{/b}{/color}{/size}"
        "System Integrity: {color=#ffcc00}[secure_bar]%%{/color}"
        ""
        "Several risky decisions left systems vulnerable."
        "Attackers exploited gaps in your awareness."
        ""
        "{i}Take the lessons learned seriously and replay the levels to improve.{/i}"

    else:
        show office_team at center with dissolve
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        "{size=+10}{color=#ff3333}{b}🚨 CRITICAL FAILURE — COMPROMISED!{/b}{/color}{/size}"
        "System Integrity: {color=#ff3333}[secure_bar]%%{/color}"
        ""
        "Multiple critical mistakes led to data breaches, credential theft, and malware infections."
        "Attackers had nearly free reign across all scenarios."
        ""
        "{i}Cybersecurity awareness is everyone's responsibility. Please review the fundamentals and try again.{/i}"

    hide office_team with dissolve
    ""
    "Thank you for playing {b}CyberSec Mastery{/b}."
    "Remember: In the real world, there are no second chances with cyber attacks."
    "Stay safe. Stay aware. Stay secure."

    return
